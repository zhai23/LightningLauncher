package com.threethan.launcher;

import android.app.Activity;
import android.app.DownloadManager;
import android.app.Instrumentation;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

public class Updater {
    private Activity context;

    public void run(Activity mainActivity) {
        context = mainActivity;
        Log.e("DOWNLOAD", "sss!!!");

        downloadFile();
//        Intent intent = new Intent(Intent.ACTION_VIEW);
//        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        intent.setDataAndType(Uri.parse("content:///" + "update.apk"),
//                "application/vnd.android.package-archive");
//        context.startActivity(intent);
    }

    private final String DownloadUrl = "https://github.com/threethan/LightningLauncher/releases/download/3.0.1/LightningLauncher-3.0.1.apk";

    public void downloadFile() {
        DownloadManager.Request request1 = new DownloadManager.Request(Uri.parse(DownloadUrl));
        request1.setDescription("Downloading Update");   //appears the same in Notification bar while downloading
        request1.setTitle(context.getTitle());
        request1.setVisibleInDownloadsUi(false);

        request1.allowScanningByMediaScanner();
        request1.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
        request1.setDestinationInExternalFilesDir(context.getApplicationContext(), "/File", "update.apk");
//

        DownloadManager manager1 = (DownloadManager) context.getSystemService(context.DOWNLOAD_SERVICE);
        Log.e("DOWNLOAD", "sdasdsad!!!");
//
        Objects.requireNonNull(manager1).enqueue(request1);
        if (DownloadManager.STATUS_SUCCESSFUL == 8) {
            String p = context.getApplicationContext().getExternalFilesDir("/File").getPath() + "/update.apk";

            Log.i("DOWNLOOAD", p);
            Log.i("DOWNLOOADDD", String.valueOf(new File(p).exists()));
            Uri apkUri = Uri.fromFile(new File(p));
            Intent intent = new Intent(Intent.ACTION_INSTALL_PACKAGE);
            intent.setData(apkUri);
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            context.startActivity(intent);
        }
    }
}

class T extends AndroidX
